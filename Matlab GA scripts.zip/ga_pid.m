
function [J] = ga_pid(p)

s = tf('s');        % Create Laplace variable
F = 1 / (s^2 + 2*s + 10); %transfer function 

Kp = p(1);   %initialize random parameters
Ki = p(2);
Kd = p(3);

C = Kp + Ki/s + Kd*s; %PID controller transfer function

open_loop = series(C,F);   %create openloop of the pid controller + our transfer function
closed_loop = feedback(open_loop,1); %create a closed loop with a gain = 1

dt=0.01;   
t = 0:dt:20;

fprintf('Kp =  %0.2d \n',Kp);
fprintf('Ki =  %0.2d \n',Ki);
fprintf('Kd =  %0.2d \n',Kd);
fprintf('---------------------\n');

error = 1 - step(closed_loop,t); %he error is the difference between the setpoint and the actual output for each sample time

J = sum(t'.*abs(error)*dt); %I used integral time absolute error criteria as a cost function (ITAE), basically we integrate the absolute error multiplied by the time over time.

end