s = tf('s');        % Create Laplace variable
F = 1 / (s^2 + 2*s + 10); %transfer function 

Kp = 165.558; 
Ki = 299.997;
Kd = 42.232;

C = Kp + Ki/s + Kd*s; %PID controller transfer function

open_loop = series(C,F);   %create openloop of the pid controller + our transfer function
closed_loop = feedback(open_loop,1); %create a closed loop with a gain = 1

step(closed_loop);

